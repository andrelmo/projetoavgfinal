﻿export class LoginAtualDto {
    public usuarioSap!: string;
    public senhaSap!: string;
}