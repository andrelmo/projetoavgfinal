﻿import { ObjetoLoginDto } from "./ObjetoLoginDto";

export class RequisicaoLerWorksItemsDto extends ObjetoLoginDto {
    constructor() {
        super();
    }
}