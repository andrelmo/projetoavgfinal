﻿export abstract class ObjetoRespostaBaseDto {
    public IsErro!: boolean;
    public MensagemErro!: string;
}