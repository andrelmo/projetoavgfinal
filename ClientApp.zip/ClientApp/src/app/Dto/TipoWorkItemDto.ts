﻿export class TipoWorkItemDto {
    public Id!: string;
    public TextoWorkItem!: string;
    public Tarefa!: string;
    public DescricaoTarefa!: string;
    public Numero!: string;
    public Valor!: number;
    public DescricaoTipoWorkItem!: string;
    public TipoWorkItem!: number;
    public Justificativa!: string;
}