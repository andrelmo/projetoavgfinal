﻿export class RequisicaoCompraDto {
    public id!: string;
    public textoWorkItem!: string;
    public tarefa!: string;
    public descricaoTarefa!: string;
    public dataCriacao!: string;
    public numero!: string;
    public tipoContratacao!: string;
    public valor!: number;
}