﻿export abstract class ObjetoLoginDto {
  public usuarioSAP!: string;
  public senhaSAP!: string;
}
