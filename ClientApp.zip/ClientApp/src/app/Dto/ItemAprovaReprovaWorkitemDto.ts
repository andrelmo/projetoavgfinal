﻿export class ItemAprovaReprovaWorkitemDto {
    public id!: string;
    public acao!: string;
}