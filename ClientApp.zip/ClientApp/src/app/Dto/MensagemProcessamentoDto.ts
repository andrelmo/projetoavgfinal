﻿export class MensagemProcessamentoDto {
    public tipoMensagem!: string;
    public mensagem!: string;
    public id!: string;
}