﻿export class InformacoesComplementaresDto {
    public texto!: string;
}