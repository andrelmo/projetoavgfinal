﻿export class LoginGeradoDto {
    public usuarioSAP!: string;
    public dataCriacao!: Date;
}
