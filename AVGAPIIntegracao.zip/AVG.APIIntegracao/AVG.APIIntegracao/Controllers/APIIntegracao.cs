﻿using Microsoft.AspNetCore.Mvc;
using System.ServiceModel;
using System.Text;

namespace AVG.APIIntegracao.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class APIIntegracao : ControllerBase
    {
        private const string CHAVE_URL_API_SAP = @"UrlApiSAP";
        private const string APPLICATION_JSON = @"application/json";

        private readonly IConfiguration _configuracao;

        public APIIntegracao(IConfiguration configuracao) : base()
        {
            this._configuracao = configuracao;
        }

        private string GetLogExecutarReprovarWorkItem(Exception Ex)
        {
            var _textoLog = new StringBuilder();

            _textoLog.AppendLine($"Erro: {Ex.Message}");

            return (_textoLog.ToString());
        }

        private string GetLogExecutarReprovarWorkItem(RequisicaoReprovarWorkItemDto requisicao, bool inicio)
        {
            var _textoLog = new StringBuilder();

            if (inicio)
            {
                _textoLog.AppendLine("Início do Método ExecutarReprovarWorkItem");
                _textoLog.AppendLine($"Id: {requisicao.Id}");
                _textoLog.AppendLine($"UsuarioSAP: {requisicao.UsuarioSAP}");
                _textoLog.AppendLine($"ReprovadoPor: {requisicao.ReprovadoPor}");
            }
            else
                _textoLog.AppendLine("Término do Método ExecutarReprovarWorkItem");

            return (_textoLog.ToString());
        }

        private string GetLogExecutarAprovarWorkItem(Exception Ex)
        {
            var _textoLog = new StringBuilder();

            _textoLog.AppendLine($"Erro: {Ex.Message}");

            return (_textoLog.ToString());
        }

        private string GetLogExecutarAprovarWorkItem(RequisicaoAprovarWorkItemDto requisicao, bool inicio)
        {
            var _textoLog = new StringBuilder();

            if (inicio)
            {
                _textoLog.AppendLine("Início do Método ExecutarAprovarWorkItem");
                _textoLog.AppendLine($"Id: {requisicao.Id}");
                _textoLog.AppendLine($"UsuarioSAP: {requisicao.UsuarioSAP}");
                _textoLog.AppendLine($"AprovadorPor: {requisicao.AprovadoPor}");
            }
            else
                _textoLog.AppendLine("Término do Método ExecutarAprovarWorkItem");

            return (_textoLog.ToString());
        }

        private string GetLogVerificarLerWorkItems(Exception excecao)
        {
            var _textoLog = new StringBuilder();

            _textoLog.AppendLine($"Erro: {excecao.Message}");

            return (_textoLog.ToString());
        }

        private string GetLogVerificarLerWorkItems(RequisicaoLerWorksItemsDto requisicao, bool inicio)
        {
            var _textoLog = new StringBuilder();

            if (inicio)
            {
                _textoLog.AppendLine("Início do Método VerificarLerWorkItems");
                _textoLog.AppendLine($"UsuarioSAP: {requisicao.UsuarioSAP}");
            }
            else
                _textoLog.AppendLine($"Término do Método VerificarLerWorkItems");

            return (_textoLog.ToString());
        }

        private string GetLogVerificarLogin(Exception excecao)
        {
            var _textoLog = new StringBuilder();

            _textoLog.AppendLine($"Erro: {excecao.Message}");

            return (_textoLog.ToString());
        }

        private string GetLogVerificarLogin(RequisicaoLoginDto requisicao, bool inicio)
        {
            var _textoLog = new StringBuilder();

            if (inicio)
            {
                _textoLog.AppendLine("Início do Método VerificarLogin");
                _textoLog.AppendLine($"UsuarioSAP: {requisicao.UsuarioSAP}");
            }
            else
                _textoLog.AppendLine($"Término do Método VerificarLogin");

            return (_textoLog.ToString());
        }

        [HttpPost("ExecutarReprovarWorkItem")]
        [Produces(typeof(RespostaReprovarWorkItemDto))]
        [ProducesResponseType(typeof(RespostaReprovarWorkItemDto), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Consumes(APPLICATION_JSON)]
        public async Task<RespostaReprovarWorkItemDto> ExecutarReprovarWorkItem([FromBody] RequisicaoReprovarWorkItemDto requisicao)
        {
            try
            {
                LogUtil.RegistrarInformacao(this.GetLogExecutarReprovarWorkItem(requisicao, true));

                if (!ModelState.IsValid)
                    return (new RespostaReprovarWorkItemDto(true, $"A requisição de Reprovar WorkItem não é válida!"));

                using (var _cliente = this.CriarClienteConexao())
                {
                    var _resultado = await _cliente.Z_APROVACAO_WORFLOW_VIA_APPAsync(this.CriarVerificarEvento(requisicao));

                    if (_resultado.Z_APROVACAO_WORFLOW_VIA_APPResponse.MENSAGENS != null &&
                        _resultado.Z_APROVACAO_WORFLOW_VIA_APPResponse.MENSAGENS.GetLength(0) > 0)
                    {
                        //Procura pela mensagem de sucesso
                        var _resultadoMensagem = this.BuscarTipoMensagem(_resultado.Z_APROVACAO_WORFLOW_VIA_APPResponse.MENSAGENS,
                                                                         ConstantesGlobais.TIPO_MENSAGEM_SUCESSO);

                        //Verificar se o login foi efetuado com sucesso
                        if (_resultadoMensagem != null)
                            return (new RespostaReprovarWorkItemDto(false, String.Empty)
                            {
                                ReprovadoPor = requisicao.ReprovadoPor,
                                Id = requisicao.Id
                            });

                        //Procura pela mensagem de erro
                        _resultadoMensagem = this.BuscarTipoMensagem(_resultado.Z_APROVACAO_WORFLOW_VIA_APPResponse.MENSAGENS,
                                                                     ConstantesGlobais.TIPO_MENSAGEM_ERRO);

                        //Verificar se a mensagem de erro foi encontrada.Login sem sucesso
                        if (_resultadoMensagem != null)
                            return (new RespostaReprovarWorkItemDto(true, _resultadoMensagem.MENSAGEM));
                    }

                    //Caso não seja retornada nenhuma mensagem.Assume-se que não funcionou.
                    return (new RespostaReprovarWorkItemDto(true, "Ocorreu um erro na Reprovação do WorkItem!"));
                }
            }
            catch (Exception Ex)
            {
                LogUtil.RegistrarErro(this.GetLogExecutarReprovarWorkItem(Ex));
                return (new RespostaReprovarWorkItemDto(true, $"Ocorreu o seguinte erro ao Reprovar o WorkItem.Erro: {Ex.Message}"));
            }
            finally
            {
                LogUtil.RegistrarInformacao(this.GetLogExecutarReprovarWorkItem(requisicao, false));
            }
        }

        [HttpPost("ExecutarAprovarWorkItem")]
        [Produces(typeof(RespostaAprovarWorkItemDto))]
        [ProducesResponseType(typeof(RespostaAprovarWorkItemDto), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Consumes(APPLICATION_JSON)]
        public async Task<RespostaAprovarWorkItemDto> ExecutarAprovarWorkItem([FromBody]RequisicaoAprovarWorkItemDto requisicao)
        {
            try
            {
                LogUtil.RegistrarInformacao(this.GetLogExecutarAprovarWorkItem(requisicao, true));

                if (!ModelState.IsValid)
                    return (new RespostaAprovarWorkItemDto(true, $"A requisição de Aprovar WorkItem não é válida!"));

                using (var _cliente = this.CriarClienteConexao())
                {
                    var _resultado = await _cliente.Z_APROVACAO_WORFLOW_VIA_APPAsync(this.CriarVerificarEvento(requisicao));

                    if (_resultado.Z_APROVACAO_WORFLOW_VIA_APPResponse.MENSAGENS != null &&
                        _resultado.Z_APROVACAO_WORFLOW_VIA_APPResponse.MENSAGENS.GetLength(0) > 0)
                    {
                        //Procura pela mensagem de sucesso
                        var _resultadoMensagem = this.BuscarTipoMensagem(_resultado.Z_APROVACAO_WORFLOW_VIA_APPResponse.MENSAGENS,
                                                                         ConstantesGlobais.TIPO_MENSAGEM_SUCESSO);

                        //Verificar se o login foi efetuado com sucesso
                        if (_resultadoMensagem != null)
                            return (new RespostaAprovarWorkItemDto(false, String.Empty)
                            {
                                AprovadoPor = requisicao.AprovadoPor,
                                Id = requisicao.Id
                            });

                        //Procura pela mensagem de erro
                        _resultadoMensagem = this.BuscarTipoMensagem(_resultado.Z_APROVACAO_WORFLOW_VIA_APPResponse.MENSAGENS,
                                                                     ConstantesGlobais.TIPO_MENSAGEM_ERRO);

                        //Verificar se a mensagem de erro foi encontrada.Login sem sucesso
                        if (_resultadoMensagem != null)
                            return (new RespostaAprovarWorkItemDto(true, _resultadoMensagem.MENSAGEM));
                    }

                    //Caso não seja retornada nenhuma mensagem.Assume-se que não funcionou.
                    return (new RespostaAprovarWorkItemDto(true, "Ocorreu um erro na Aprovação do WorkItem!"));
                }
            }
            catch (Exception Ex)
            {
                LogUtil.RegistrarErro(this.GetLogExecutarAprovarWorkItem(Ex));
                return (new RespostaAprovarWorkItemDto(true, $"Ocorreu o seguinte erro ao Aprovar o WorkItem.Erro: {Ex.Message}"));
            }
            finally
            {
                LogUtil.RegistrarInformacao(this.GetLogExecutarAprovarWorkItem(requisicao, false));
            }
        }

        [HttpPost("VerificarLerWorkItems")]
        [Produces(typeof(RespostaLerWorksItemsDto))]
        [ProducesResponseType(typeof(RespostaLerWorksItemsDto), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Consumes(APPLICATION_JSON)]
        public async Task<RespostaLerWorksItemsDto> VerificarLerWorkItems([FromBody] RequisicaoLerWorksItemsDto requisicaoLerWorkItems)
        {
            try
            {
                LogUtil.RegistrarInformacao(this.GetLogVerificarLerWorkItems(requisicaoLerWorkItems, true));
                
                if (!ModelState.IsValid)
                    return (new RespostaLerWorksItemsDto(true, $"A requisição não é válida!"));

                using (var _cliente = this.CriarClienteConexao())
                {
                    var _resultado = await _cliente.Z_APROVACAO_WORFLOW_VIA_APPAsync(this.CriarVerificarEvento(requisicaoLerWorkItems));

                    if (_resultado.Z_APROVACAO_WORFLOW_VIA_APPResponse.MENSAGENS != null &&
                        _resultado.Z_APROVACAO_WORFLOW_VIA_APPResponse.MENSAGENS.GetLength(0) > 0)
                    {
                        //Procura pela mensagem de sucesso
                        var _resultadoMensagem = this.BuscarTipoMensagem(_resultado.Z_APROVACAO_WORFLOW_VIA_APPResponse.MENSAGENS,
                                                                         ConstantesGlobais.TIPO_MENSAGEM_SUCESSO);

                        //Verificar se o login foi efetuado com sucesso
                        if (_resultadoMensagem != null)
                        {
                            var _resposta = new RespostaLerWorksItemsDto(false, String.Empty)
                            {
                                Contrato = this.CriarDadosContrato(_resultado.Z_APROVACAO_WORFLOW_VIA_APPResponse.CONTRATO),
                                Medicao = this.CriarDadosMediciao(_resultado.Z_APROVACAO_WORFLOW_VIA_APPResponse.MEDICAO),
                                Pedido = this.CriarDadosContrato(_resultado.Z_APROVACAO_WORFLOW_VIA_APPResponse.PEDIDO),
                                Requisicao = this.CriarRequisicaoCompra(_resultado.Z_APROVACAO_WORFLOW_VIA_APPResponse.REQUISICAO),
                                Mensagens = this.CriarMensagemProcessamento(_resultado.Z_APROVACAO_WORFLOW_VIA_APPResponse.MENSAGENS)
                            };

                            return (this.PrepararRespostaLerWorkItems(_resposta));
                        }

                        //Procura pela mensagem de erro
                        _resultadoMensagem = this.BuscarTipoMensagem(_resultado.Z_APROVACAO_WORFLOW_VIA_APPResponse.MENSAGENS,
                                                                     ConstantesGlobais.TIPO_MENSAGEM_ERRO);

                        //Verificar se a mensagem de erro foi encontrada.Login sem sucesso
                        if (_resultadoMensagem != null)
                            return (new RespostaLerWorksItemsDto(true, _resultadoMensagem.MENSAGEM));
                    }

                    //Caso não seja retornada nenhuma mensagem.Assume-se que não funcionou.
                    return (new RespostaLerWorksItemsDto(true, "Ocorreu um erro na verificação da Leitura dos WorkItems!"));
                }
            }
            catch (Exception Ex)
            {
                LogUtil.RegistrarErro(this.GetLogVerificarLerWorkItems(Ex));
                return (new RespostaLerWorksItemsDto(true, $"Ocorreu o seguinte erro ao Verificar os WorkItems.Erro: {Ex.Message}"));
            }
            finally
            {
                LogUtil.RegistrarInformacao(this.GetLogVerificarLerWorkItems(requisicaoLerWorkItems, false));
            }
        }

        private RespostaLerWorksItemsDto PrepararRespostaLerWorkItems(RespostaLerWorksItemsDto resposta)
        {
            resposta.ListaTipoWorkItems = new List<TipoWorkItemDto>();

            foreach (var itemContrato in resposta.Contrato)
            {
                resposta.ListaTipoWorkItems.Add(this.CriarTipoWorkItem(itemContrato.Id, itemContrato.TextoWorkItem, itemContrato.Tarefa,
                    itemContrato.DescricaoTarefa, itemContrato.Numero, itemContrato.Valor, ConstantesGlobais.TIPO_WORK_ITEM_CONTRATO,
                    TipoWorkItem.Contrato));
            }

            foreach (var itemMedicao in resposta.Medicao)
            {
                resposta.ListaTipoWorkItems.Add(this.CriarTipoWorkItem(itemMedicao.Id, itemMedicao.TextoWorkItem, itemMedicao.Tarefa,
                    itemMedicao.DescricaoTarefa,itemMedicao.Numero,itemMedicao.Total,ConstantesGlobais.TIPO_WORK_ITEM_MEDICAO,
                    TipoWorkItem.Medicao));
            }

            foreach (var itemPedido in resposta.Pedido)
            {
                resposta.ListaTipoWorkItems.Add(this.CriarTipoWorkItem(itemPedido.Id, itemPedido.TextoWorkItem, itemPedido.Tarefa,
                    itemPedido.DescricaoTarefa,itemPedido.Numero,itemPedido.Valor, ConstantesGlobais.TIPO_WORK_ITEM_PEDIDO, TipoWorkItem.Pedido));
            }

            foreach (var itemRequisicao in resposta.Requisicao)
            {
                resposta.ListaTipoWorkItems.Add(this.CriarTipoWorkItem(itemRequisicao.Id, itemRequisicao.TextoWorkItem, itemRequisicao.Tarefa,
                    itemRequisicao.DescricaoTarefa, itemRequisicao.Numero, itemRequisicao.Valor, ConstantesGlobais.TIPO_WORK_ITEM_REQUISICAO, TipoWorkItem.Requisicao));
            }

            return (resposta);
        }

        private TipoWorkItemDto CriarTipoWorkItem(string id, string textoWorkItem,string tarefa, string descricaoTarefa, string numero,
            decimal valor,string descricaoTipoWorkItem,TipoWorkItem tipoWorkItem)
        {
            return (new TipoWorkItemDto()
            {
                DescricaoTarefa = descricaoTarefa,
                DescricaoTipoWorkItem = descricaoTipoWorkItem,
                Id = id,
                Numero = numero,
                Tarefa = tarefa,
                TextoWorkItem = textoWorkItem,
                TipoWorkItem = tipoWorkItem,
                Valor = valor
            });
        }

        private MensagemProcessamentoDto CriarMensagemProcessamento(ServicoIntegracaoSAP.ZSAPP_MENSAGEM_PROCESAMENTO mensagemProcessamento)
        {
            var _resultado = new MensagemProcessamentoDto()
            {
                Id = mensagemProcessamento.ID,
                Mensagem = mensagemProcessamento.MENSAGEM,
                TipoMensagem = mensagemProcessamento.TIPO_MENSAGEM
            };

            return (_resultado);
        }

        private List<MensagemProcessamentoDto> CriarMensagemProcessamento(ServicoIntegracaoSAP.ZSAPP_MENSAGEM_PROCESAMENTO[] mensagemProcessamento)
        {
            var _resultado = new List<MensagemProcessamentoDto>();

            foreach (var _itemMensagem in mensagemProcessamento)
                _resultado.Add(this.CriarMensagemProcessamento(_itemMensagem));

            return (_resultado);
        }

        private RequisicaoCompraDto CriarRequisicaoCompra(ServicoIntegracaoSAP.ZES_APP_SAIDA_DADOS_REQCOMPRA dadosReqCompra)
        {
            var _resultado = new RequisicaoCompraDto()
            {
                DataCriacao = dadosReqCompra.DATA_CRIACAO,
                DescricaoTarefa = dadosReqCompra.DESCRICAO_TAREFA,
                Id = dadosReqCompra.ID,
                Numero = dadosReqCompra.NUMERO,
                Tarefa = dadosReqCompra.TAREFA,
                TextoWorkItem = dadosReqCompra.TEXTO_WORKITEM,
                TipoContratacao = dadosReqCompra.TIPO_DE_CONTRATACAO,
                Valor = dadosReqCompra.VALOR
            };

            return (_resultado);
        }

        private List<RequisicaoCompraDto> CriarRequisicaoCompra(ServicoIntegracaoSAP.ZES_APP_SAIDA_DADOS_REQCOMPRA[] dadosReqCompra)
        {
            var _resultado = new List<RequisicaoCompraDto>();

            foreach (var _itemReqCompra in dadosReqCompra)
                _resultado.Add(this.CriarRequisicaoCompra(_itemReqCompra));

            return (_resultado);
        }

        private List<DadosMedicaoDto> CriarDadosMediciao(ServicoIntegracaoSAP.ZES_APP_SAIDA_DADOS_MEDICAO[] dadosMedicao)
        {
            var _resultado = new List<DadosMedicaoDto>();

            foreach (var _itemMedicao in dadosMedicao)
                _resultado.Add(this.CriarDadosMediciao(_itemMedicao));

            return (_resultado);
        }

        private DadosMedicaoDto CriarDadosMediciao(ServicoIntegracaoSAP.ZES_APP_SAIDA_DADOS_MEDICAO dadosMedicao)
        {
            var _resultado = new DadosMedicaoDto()
            {
                DataCriacao = dadosMedicao.DATA_CRIACAO,
                DescricaoTarefa = dadosMedicao.DESCRICAO_TAREFA,
                Id = dadosMedicao.ID,
                Numero = dadosMedicao.NUMERO,
                Pedido = dadosMedicao.PEDIDO,
                Tarefa = dadosMedicao.TAREFA,
                TextoWorkItem = dadosMedicao.TEXTO_WORKITEM,
                Total = dadosMedicao.TOTAL,
                ValorBoletim = dadosMedicao.VALOR_BOLETIM
            };

            if (dadosMedicao.INFORMACOES_COMPLEMENTARES != null)
            {
                foreach (var _itemInfoComplementar in dadosMedicao.INFORMACOES_COMPLEMENTARES)
                    _resultado.InformacoesComplementares.Add(new InformacoesComplementaresDto(_itemInfoComplementar.TEXTO));
            }

            return (_resultado);
        }

        private List<DadosContratoDto> CriarDadosContrato(ServicoIntegracaoSAP.ZES_APP_SAIDA_DADOS_CONTRATO[] dadosContrato)
        {
            var _listaDadosContrato = new List<DadosContratoDto>();

            foreach (var _itemDadosContrato in dadosContrato)
                _listaDadosContrato.Add(this.CriarDadosContrato(_itemDadosContrato));

            return (_listaDadosContrato);
        }

        private DadosContratoDto CriarDadosContrato(ServicoIntegracaoSAP.ZES_APP_SAIDA_DADOS_CONTRATO dadosContrato)
        {
            var _resultado = new DadosContratoDto()
            {
                DataCriacao = dadosContrato.DATA_CRIACAO,
                DescricaoTarefa = dadosContrato.DESCRICAO_TAREFA,
                Fornecedor = dadosContrato.FORNECEDOR,
                Id = dadosContrato.ID,
                Numero = dadosContrato.NUMERO,
                Tarefa = dadosContrato.TAREFA,
                TextoWorkItem = dadosContrato.TEXTO_WORKITEM,
                TipoDeContrato = dadosContrato.TIPO_DE_CONTRATO,
                UltimaAprovacao = dadosContrato.ULTIMA_APROVACAO,
                Valor = dadosContrato.VALOR
            };

            if (dadosContrato.INFORMACOES_COMPLEMENTARES != null)
            {
                foreach (var _infoComp in dadosContrato.INFORMACOES_COMPLEMENTARES)
                    _resultado.InformacoesComplementares.Add(new InformacoesComplementaresDto(_infoComp.TEXTO));
            }

            return (_resultado);
        }

        [HttpPost("VerificarLogin")]
        [Produces(typeof(RespostaLoginDto))]
        [ProducesResponseType(typeof(RespostaLoginDto), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Consumes(APPLICATION_JSON)]
        public async Task<RespostaLoginDto> VerificarLogin([FromBody] RequisicaoLoginDto requisicaoLogin)
        {
            try
            {
                LogUtil.RegistrarInformacao(this.GetLogVerificarLogin(requisicaoLogin, true));

                if (!ModelState.IsValid)
                    return (new RespostaLoginDto(true, $"A requisição não é válida!"));

                using (var _cliente = this.CriarClienteConexao())
                {
                    var _resultado = await _cliente.Z_APROVACAO_WORFLOW_VIA_APPAsync(this.CriarVerificarEvento(requisicaoLogin));

                    if (_resultado.Z_APROVACAO_WORFLOW_VIA_APPResponse.MENSAGENS != null &&
                        _resultado.Z_APROVACAO_WORFLOW_VIA_APPResponse.MENSAGENS.GetLength(0) > 0)
                    {
                        //Procura pela mensagem de sucesso
                        var _resultadoMensagem = this.BuscarTipoMensagem(_resultado.Z_APROVACAO_WORFLOW_VIA_APPResponse.MENSAGENS,
                                                                         ConstantesGlobais.TIPO_MENSAGEM_SUCESSO);

                        //Verificar se o login foi efetuado com sucesso
                        if (_resultadoMensagem != null)
                            return (new RespostaLoginDto(false, String.Empty)
                            {
                                LoginGerado = new LoginGeradoDto(requisicaoLogin.UsuarioSAP, DateTime.Now)
                            });

                        //Procura pela mensagem de erro
                        _resultadoMensagem = this.BuscarTipoMensagem(_resultado.Z_APROVACAO_WORFLOW_VIA_APPResponse.MENSAGENS,
                                                                     ConstantesGlobais.TIPO_MENSAGEM_ERRO);

                        //Verificar se a mensagem de erro foi encontrada.Login sem sucesso
                        if (_resultadoMensagem != null)
                            return (new RespostaLoginDto(true, _resultadoMensagem.MENSAGEM));
                    }

                    //Caso não seja retornada nenhuma mensagem.Assume-se que não funcionou.
                    return (new RespostaLoginDto(true, "Login ou senha incorretos!"));
                }
            }
            catch (Exception Ex)
            {
                LogUtil.RegistrarErro(this.GetLogVerificarLogin(Ex));
                return (new RespostaLoginDto(true, $"Ocorreu o seguinte erro ao tentar verificar o login.Erro: {Ex.Message}"));
            }
            finally
            {
                LogUtil.RegistrarInformacao(this.GetLogVerificarLogin(requisicaoLogin, false));
            }
        }

        private ServicoIntegracaoSAP.ZSAPP_MENSAGEM_PROCESAMENTO BuscarTipoMensagem(ServicoIntegracaoSAP.ZSAPP_MENSAGEM_PROCESAMENTO[] listaMensagens,
            string tipoMensagemBuscar)
        {
            return (listaMensagens.Where(i => i.TIPO_MENSAGEM == tipoMensagemBuscar).FirstOrDefault());
        }

        private ServicoIntegracaoSAP.Z_APROVACAO_WORFLOW_VIA_APP1 CriarVerificarEvento(RequisicaoReprovarWorkItemDto requisicaoLerWorkItems)
        {
            return (this.CriarVerificarEvento(ConstantesGlobais.EVENTO_REPROVAR_WORK_ITEM, requisicaoLerWorkItems.UsuarioSAP, requisicaoLerWorkItems.SenhaSAP));
        }

        private ServicoIntegracaoSAP.Z_APROVACAO_WORFLOW_VIA_APP1 CriarVerificarEvento(RequisicaoAprovarWorkItemDto requisicaoLerWorkItems)
        {
            return (this.CriarVerificarEvento(ConstantesGlobais.EVENTO_APROVAR_WORK_ITEM, requisicaoLerWorkItems.UsuarioSAP, requisicaoLerWorkItems.SenhaSAP));
       }

        private ServicoIntegracaoSAP.Z_APROVACAO_WORFLOW_VIA_APP1 CriarVerificarEvento(RequisicaoLerWorksItemsDto requisicaoLerWorkItems)
        {
            return (this.CriarVerificarEvento(ConstantesGlobais.EVENTO_LER_WORK_ITEMS, requisicaoLerWorkItems.UsuarioSAP, requisicaoLerWorkItems.SenhaSAP));
        }

        private ServicoIntegracaoSAP.Z_APROVACAO_WORFLOW_VIA_APP1 CriarVerificarEvento(RequisicaoLoginDto requisicaoLogin)
        {
            return (this.CriarVerificarEvento(ConstantesGlobais.EVENTO_VERIFICAR_LOGIN, requisicaoLogin.UsuarioSAP,requisicaoLogin.SenhaSAP));
        }

        private ServicoIntegracaoSAP.Z_APROVACAO_WORFLOW_VIA_APP1 CriarVerificarEvento(string evento, string usuarioSAP, string senhaSAP)
        {
            return (new ServicoIntegracaoSAP.Z_APROVACAO_WORFLOW_VIA_APP1()
            {
                SENHA_SAP = senhaSAP,
                USUARIO_SAP = usuarioSAP,
                EVENTO = evento
            });
        }

        private ServicoIntegracaoSAP.Z_APROVACAO_WORFLOW_VIA_APPClient CriarClienteConexao()
        {
            return (new ServicoIntegracaoSAP.Z_APROVACAO_WORFLOW_VIA_APPClient(this.CriarBasicHttpBinding(), this.CriarUrlAcessoApiSap()));
        }

        private EndpointAddress CriarUrlAcessoApiSap()
        {
            return (new EndpointAddress(this._configuracao.GetValue<string>(CHAVE_URL_API_SAP)));
        }

        private WSHttpBinding CriarBasicHttpBinding()
        {
            return (new WSHttpBinding(SecurityMode.TransportWithMessageCredential));
        }
    }
}