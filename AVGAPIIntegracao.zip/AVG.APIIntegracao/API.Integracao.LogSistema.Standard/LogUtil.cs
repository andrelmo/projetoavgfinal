﻿using API.Integracao.Constantes.Standard;
using API.Integracao.Enumeradores.Standard;
using Serilog;
using System;

namespace API.Integracao.LogSistema.Standard
{
    public static class LogUtil
    {
        public static void Registrar(string mensagem, TipoLog tipoLog)
        {
            if (tipoLog == TipoLog.Informacao)
                RegistrarInformacao(mensagem);
            else if (tipoLog == TipoLog.Alerta)
                RegistrarAlerta(mensagem);
            else
                RegistrarErro(mensagem);
        }

        public static void RegistrarInformacao(string mensagem)
        {
            Log.Information(GetMensagemFormatada(mensagem));
        }

        public static void RegistrarAlerta(string mensagem)
        {
            Log.Warning(GetMensagemFormatada(mensagem));
        }

        public static void RegistrarErro(string mensagem)
        {
            Log.Error(GetMensagemFormatada(mensagem));
        }

        private static string GetMensagemFormatada(string mensagem)
        {
            return ($"{DateTime.Now.ToString(ConstantesGlobais.FORMATAR_DATA_HORA)} - {mensagem}");
        }
    }
}