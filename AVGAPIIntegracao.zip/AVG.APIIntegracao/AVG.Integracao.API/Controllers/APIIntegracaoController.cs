﻿using API.Integracao.Constantes.Standard;
using API.Integracao.DTO.Standard;
using API.Integracao.Enumeradores.Standard;
using API.Integracao.LogSistema.Standard;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Web.Http.Cors;
using System.ServiceModel;

namespace AVG.Integracao.API.Controllers
{
    /// <summary>
    /// APIIntegração
    /// </summary>
    [System.Web.Mvc.RoutePrefix("api/APIIntegracao")]
    [EnableCors(origins: "*", headers: "*", methods: "*")] // tune to your needs
    public class APIIntegracaoController : System.Web.Http.ApiController
    {
        private const string CHAVE_URL_API_SAP = @"UrlApiSAP";
        private const string APPLICATION_JSON = @"application/json";

        private string GetLogExecutarReprovarWorkItem(Exception Ex)
        {
            var _textoLog = new StringBuilder();

            _textoLog.AppendLine($"Erro: {Ex.Message}");

            return (_textoLog.ToString());
        }

        private string GetLogExecutarReprovarWorkItem(RequisicaoReprovarWorkItemDto requisicao, bool inicio)
        {
            var _textoLog = new StringBuilder();

            if (inicio)
            {
                _textoLog.AppendLine("Início do Método ExecutarReprovarWorkItem");

                foreach (var _item in requisicao.Item)
                    _textoLog.AppendLine($"Id: {_item.Id}");

                _textoLog.AppendLine($"UsuarioSAP: {requisicao.UsuarioSAP}");
                _textoLog.AppendLine($"ReprovadoPor: {requisicao.ReprovadoPor}");
            }
            else
                _textoLog.AppendLine("Término do Método ExecutarReprovarWorkItem");

            return (_textoLog.ToString());
        }

        private string GetLogExecutarAprovarWorkItem(Exception Ex)
        {
            var _textoLog = new StringBuilder();

            _textoLog.AppendLine($"Erro: {Ex.Message}");

            return (_textoLog.ToString());
        }

        private string GetLogExecutarAprovarWorkItem(RequisicaoAprovarWorkItemDto requisicao, bool inicio)
        {
            var _textoLog = new StringBuilder();

            if (inicio)
            {
                _textoLog.AppendLine("Início do Método ExecutarAprovarWorkItem");

                foreach (var _item in requisicao.Item)
                    _textoLog.AppendLine($"Id: {_item}");

                _textoLog.AppendLine($"UsuarioSAP: {requisicao.UsuarioSAP}");
                _textoLog.AppendLine($"AprovadorPor: {requisicao.AprovadoPor}");
            }
            else
                _textoLog.AppendLine("Término do Método ExecutarAprovarWorkItem");

            return (_textoLog.ToString());
        }

        private string GetLogVerificarLerWorkItems(Exception excecao)
        {
            var _textoLog = new StringBuilder();

            _textoLog.AppendLine($"Erro: {excecao.Message}");

            return (_textoLog.ToString());
        }

        private string GetLogVerificarLerWorkItems(RequisicaoLerWorksItemsDto requisicao, bool inicio)
        {
            var _textoLog = new StringBuilder();

            if (inicio)
            {
                _textoLog.AppendLine("Início do Método VerificarLerWorkItems");
                _textoLog.AppendLine($"UsuarioSAP: {requisicao.UsuarioSAP}");
            }
            else
                _textoLog.AppendLine($"Término do Método VerificarLerWorkItems");

            return (_textoLog.ToString());
        }

        private string GetLogVerificarLogin(Exception excecao)
        {
            var _textoLog = new StringBuilder();

            _textoLog.AppendLine($"Erro: {excecao.Message}");

            return (_textoLog.ToString());
        }

        private string GetLogVerificarLogin(RequisicaoLoginDto requisicao, bool inicio)
        {
            var _textoLog = new StringBuilder();

            if (inicio)
            {
                _textoLog.AppendLine("Início do Método VerificarLogin");
                _textoLog.AppendLine($"UsuarioSAP: {requisicao.UsuarioSAP}");
            }
            else
                _textoLog.AppendLine($"Término do Método VerificarLogin");

            return (_textoLog.ToString());
        }

        /// <summary>
        /// Método responsável por reprovar um WorkItem
        /// </summary>
        /// <param name="requisicao">Work Item a ser reprovado</param>
        /// <returns>Retorna uma resposta indicando se o WorkItem foi reprovado</returns>
        [HttpPost()]
        [Route("ExecutarReprovarWorkItem")]
        [Produces(typeof(RespostaReprovarWorkItemDto))]
        [ProducesResponseType(typeof(RespostaReprovarWorkItemDto), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Consumes(APPLICATION_JSON)]
        public async Task<RespostaReprovarWorkItemDto> ExecutarReprovarWorkItem([FromBody] RequisicaoReprovarWorkItemDto requisicao)
        {
            try
            {
                LogUtil.RegistrarInformacao(this.GetLogExecutarReprovarWorkItem(requisicao, true));

                if (!ModelState.IsValid)
                    return (new RespostaReprovarWorkItemDto(true, $"A requisição de Reprovar WorkItem não é válida!"));

                //Dados fakes somente para teste.Remover depois
                /*return (new RespostaReprovarWorkItemDto()
                {
                    ReprovadoPor = requisicao.ReprovadoPor
                });*/

                using (var _cliente = this.CriarClienteConexao())
                {
                    var _resultado = _cliente.Z_APROVACAO_WORFLOW_VIA_APP(this.CriarVerificarEvento(requisicao));

                    if (_resultado.MENSAGENS != null &&
                        _resultado.MENSAGENS.GetLength(0) > 0)
                    {
                        //Procura pela mensagem de sucesso
                        var _resultadoMensagem = this.BuscarTipoMensagem(_resultado.MENSAGENS, ConstantesGlobais.TIPO_MENSAGEM_SUCESSO);

                        //Verificar se o login foi efetuado com sucesso
                        if (_resultadoMensagem != null)
                            return (new RespostaReprovarWorkItemDto(false, String.Empty)
                            {
                                ReprovadoPor = requisicao.ReprovadoPor
                            });

                        //Procura pela mensagem de erro
                        _resultadoMensagem = this.BuscarTipoMensagem(_resultado.MENSAGENS, ConstantesGlobais.TIPO_MENSAGEM_ERRO);

                        //Verificar se a mensagem de erro foi encontrada.Login sem sucesso
                        if (_resultadoMensagem != null)
                            return (new RespostaReprovarWorkItemDto(true, _resultadoMensagem.MENSAGEM));
                    }

                    //Caso não seja retornada nenhuma mensagem.Assume-se que não funcionou.
                    return (new RespostaReprovarWorkItemDto(true, "Ocorreu um erro na Reprovação do WorkItem!"));
                }
            }
            catch (Exception Ex)
            {
                LogUtil.RegistrarErro(this.GetLogExecutarReprovarWorkItem(Ex));
                return (new RespostaReprovarWorkItemDto(true, $"Ocorreu o seguinte erro ao Reprovar o WorkItem.Erro: {Ex.Message}"));
            }
            finally
            {
                LogUtil.RegistrarInformacao(this.GetLogExecutarReprovarWorkItem(requisicao, false));
            }
        }

        /// <summary>
        /// Método responsável por Aprovar um WorkItem
        /// </summary>
        /// <param name="requisicao">WorkItem a ser aprovado</param>
        /// <returns>Retorna uma resposta indicando se o WorkItem foi aprovado</returns>
        [HttpPost()]
        [Route("ExecutarAprovarWorkItem")]
        [Produces(typeof(RespostaAprovarWorkItemDto))]
        [ProducesResponseType(typeof(RespostaAprovarWorkItemDto), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Consumes(APPLICATION_JSON)]
        public async Task<RespostaAprovarWorkItemDto> ExecutarAprovarWorkItem([FromBody] RequisicaoAprovarWorkItemDto requisicao)
        {
            try
            {
                LogUtil.RegistrarInformacao(this.GetLogExecutarAprovarWorkItem(requisicao, true));

                if (!ModelState.IsValid)
                    return (new RespostaAprovarWorkItemDto(true, $"A requisição de Aprovar WorkItem não é válida!"));

                //Dados fakes somente para teste. Remover depois
                /*return (new RespostaAprovarWorkItemDto(false)
                {
                    AprovadoPor = requisicao.AprovadoPor
                });*/

                using (var _cliente = this.CriarClienteConexao())
                {
                    var _resultado = _cliente.Z_APROVACAO_WORFLOW_VIA_APP(this.CriarVerificarEvento(requisicao));

                    if (_resultado.MENSAGENS != null &&
                        _resultado.MENSAGENS.GetLength(0) > 0)
                    {
                        //Procura pela mensagem de sucesso
                        var _resultadoMensagem = this.BuscarTipoMensagem(_resultado.MENSAGENS, ConstantesGlobais.TIPO_MENSAGEM_SUCESSO);

                        //Verificar se o login foi efetuado com sucesso
                        if (_resultadoMensagem != null)
                            return (new RespostaAprovarWorkItemDto(false, String.Empty)
                            {
                                AprovadoPor = requisicao.AprovadoPor
                            });

                        //Procura pela mensagem de erro
                        _resultadoMensagem = this.BuscarTipoMensagem(_resultado.MENSAGENS, ConstantesGlobais.TIPO_MENSAGEM_ERRO);

                        //Verificar se a mensagem de erro foi encontrada.Login sem sucesso
                        if (_resultadoMensagem != null)
                            return (new RespostaAprovarWorkItemDto(true, _resultadoMensagem.MENSAGEM));
                    }

                    //Caso não seja retornada nenhuma mensagem.Assume-se que não funcionou.
                    return (new RespostaAprovarWorkItemDto(true, "Ocorreu um erro na Aprovação do WorkItem!"));
                }
            }
            catch (Exception Ex)
            {
                LogUtil.RegistrarErro(this.GetLogExecutarAprovarWorkItem(Ex));
                return (new RespostaAprovarWorkItemDto(true, $"Ocorreu o seguinte erro ao Aprovar o WorkItem.Erro: {Ex.Message}"));
            }
            finally
            {
                LogUtil.RegistrarInformacao(this.GetLogExecutarAprovarWorkItem(requisicao, false));
            }
        }

        /// <summary>
        /// Método responsável por retornar uma lista de work items
        /// </summary>
        /// <param name="requisicaoLerWorkItems">Requisição para retornar a lista de work de items</param>
        /// <returns>Retorna uma lista de work items</returns>
        [HttpPost()]
        [Route("VerificarLerWorkItems")]
        [Produces(typeof(RespostaLerWorksItemsDto))]
        [ProducesResponseType(typeof(RespostaLerWorksItemsDto), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Consumes(APPLICATION_JSON)]
        public async Task<RespostaLerWorksItemsDto> VerificarLerWorkItems([FromBody] RequisicaoLerWorksItemsDto requisicaoLerWorkItems)
        {
            try
            {
                LogUtil.RegistrarInformacao(this.GetLogVerificarLerWorkItems(requisicaoLerWorkItems, true));

                if (!ModelState.IsValid)
                    return (new RespostaLerWorksItemsDto(true, $"A requisição não é válida!"));

                //Dados fakes somente para teste. Remover depois
                /*var _respostaLocal = new RespostaLerWorksItemsDto(false);
                var _contador = 1;

                _respostaLocal.Contrato = new List<DadosContratoDto>();

                for (var i = 0; i < 10;i++)
                {
                    _respostaLocal.Contrato.Add(new DadosContratoDto()
                    {
                        DataCriacao = DateTime.Now.ToString(ConstantesGlobais.FORMATAR_DATA),
                        DescricaoTarefa = $"Tarefa de Dados do Contrato {i}",
                        Fornecedor = $"Fornecedor de Dados do Contrato {i}",
                        Id = _contador.ToString(),
                        Numero = i.ToString(),
                        Tarefa = $"Tarefa de Dados do Contrato {i}",
                        TextoWorkItem = $"Work Item de Dados do Contrato da Tarefa {i}",
                        TipoDeContrato = $"Tipo de Contrato de Dados do Contrato {i}",
                        Valor = 1500 * (i + 1)
                    });

                    _contador++;
                }

                _respostaLocal.Medicao = new List<DadosMedicaoDto>();

                for (var i = 0; i < 10; i++)
                {
                    var _itemMedicao = new DadosMedicaoDto()
                    {
                        DataCriacao = DateTime.Now.ToString(ConstantesGlobais.FORMATAR_DATA),
                        DescricaoTarefa = $"Tarea da Medição {i}",
                        Numero = i.ToString(),
                        Pedido = i.ToString(),
                        Tarefa = $"Tarefa de Medição {i}",
                        Total = 2500 * (i + 1),
                        ValorBoletim = 3500 * (i + 1),
                        Id = _contador.ToString()
                    };

                    _itemMedicao.TextoWorkItem = $"Número: {_itemMedicao.Numero} " + Environment.NewLine +
                                                 $"Pedido: {_itemMedicao.Pedido} " + Environment.NewLine +
                                                 $"Total: {_itemMedicao.Total} " + Environment.NewLine +
                                                 $"Valor do Boletim: {_itemMedicao.ValorBoletim}";

                    _respostaLocal.Medicao.Add(_itemMedicao);
                    _contador++;
                }

                _respostaLocal.Pedido = new List<DadosContratoDto>();

                for (var i = 0; i < 10; i++)
                {
                    var _itemPedido = new DadosContratoDto()
                    {
                        DataCriacao = DateTime.Now.ToString(ConstantesGlobais.FORMATAR_DATA),
                        DescricaoTarefa = $"Tarefa do Pedido {i}",
                        Fornecedor = $"Fornecedor de Pedido {i}",
                        Numero = i.ToString(),
                        Tarefa = $"Tarefa de Pedido {i}",
                        TipoDeContrato = $"Tipo de Contrato de Pedido {i}",
                        Valor = 4500 * (i + 1),
                        Id = _contador.ToString()
                    };

                    _itemPedido.TextoWorkItem = $"Número: {_itemPedido.Numero} " + Environment.NewLine +
                                                $"Valor: {_itemPedido.Valor} " + Environment.NewLine +
                                                $"Tipo de Contratação Pedido: {_itemPedido.TipoDeContrato} " + Environment.NewLine +
                                                $"Fornecedor: {_itemPedido.Fornecedor} " + Environment.NewLine +
                                                $"Última Aprovação: {_itemPedido.UltimaAprovacao}";

                    //Avisar o Eduardo em Pedido não tem os campos (Objeto da Contratação)
                    _respostaLocal.Pedido.Add(_itemPedido);
                    _contador++;
                }

                _respostaLocal.Requisicao = new List<RequisicaoCompraDto>();

                for (var i = 0; i < 10; i++)
                {
                    var _itemRequisicao = new RequisicaoCompraDto()
                    {
                        DataCriacao = DateTime.Now.ToString(ConstantesGlobais.FORMATAR_DATA),
                        DescricaoTarefa = $"Tarefa da Requisição de Compra {i}",
                        Numero = i.ToString(),
                        Tarefa = $"Tarefa da Requisição de Compra {i}",
                        TipoContratacao = $"Tipo de Contratação de Requisição de Compra {i}",
                        Valor = 500 * (i + 1),
                        Id = _contador.ToString()
                    };

                    _itemRequisicao.TextoWorkItem = $"Número: {_itemRequisicao.Numero} " + Environment.NewLine +
                                                    $"Valor: {_itemRequisicao.Valor} " + Environment.NewLine +
                                                    $"Tipo de Contratação Pedido: {_itemRequisicao.TipoContratacao} " + Environment.NewLine;

                    //Avisar o Eduardo que em Requisição de Compra não tem os campos (Fornecedor,Objeto da Contratação,Última Aprovação)
                    _respostaLocal.Requisicao.Add(_itemRequisicao);
                    _contador++;
                }

                return (this.PrepararRespostaLerWorkItems(_respostaLocal));*/

                /*BasicHttpBinding basicAuthBinding = new BasicHttpBinding(BasicHttpSecurityMode.TransportCredentialOnly);
                basicAuthBinding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;
                EndpointAddress basicAuthEndpoint = new EndpointAddress(
                    "http://teste.avg.com.br:8088/sap/bc/srt/rfc/sap/z_aprovacao_worflow_via_app/500/z_aprovacao_worflow_via_app/zaprovacaowfviaapp");

                var _srvSap = new SrvSap.Z_APROVACAO_WORFLOW_VIA_APPClient(basicAuthBinding, basicAuthEndpoint);
                var _srvApp = new SrvSap.Z_APROVACAO_WORFLOW_VIA_APP();

                _srvApp.SENHA_SAP = "Lpj@func123456";
                _srvApp.USUARIO_SAP = "lpj.func1";
                _srvApp.EVENTO = ConstantesGlobais.EVENTO_LER_WORK_ITEMS;

                _srvSap.ClientCredentials.UserName.UserName = "APP_WF";
                _srvSap.ClientCredentials.UserName.Password = "p@Lpj@2022!!";

                var _resultado = await _srvSap.Z_APROVACAO_WORFLOW_VIA_APPAsync(_srvApp);

                return (new RespostaLerWorksItemsDto());*/
                
                using (var _cliente = this.CriarClienteConexao())
                {
                    var _resultado = _cliente.Z_APROVACAO_WORFLOW_VIA_APP(this.CriarVerificarEvento(requisicaoLerWorkItems));

                    if (_resultado.MENSAGENS != null &&
                        _resultado.MENSAGENS.GetLength(0) > 0)
                    {
                        //Procura pela mensagem de sucesso
                        var _resultadoMensagem = this.BuscarTipoMensagem(_resultado.MENSAGENS, ConstantesGlobais.TIPO_MENSAGEM_SUCESSO);

                        //Verificar se o login foi efetuado com sucesso
                        if (_resultadoMensagem != null)
                        {
                            var _resposta = new RespostaLerWorksItemsDto(false, String.Empty)
                            {
                                Contrato = this.CriarDadosContrato(_resultado.CONTRATO),
                                Medicao = this.CriarDadosMediciao(_resultado.MEDICAO),
                                Pedido = this.CriarDadosContrato(_resultado.PEDIDO),
                                Requisicao = this.CriarRequisicaoCompra(_resultado.REQUISICAO),
                                Mensagens = this.CriarMensagemProcessamento(_resultado.MENSAGENS)
                            };

                            return (this.PrepararRespostaLerWorkItems(_resposta));
                        }

                        //Procura pela mensagem de erro
                        _resultadoMensagem = this.BuscarTipoMensagem(_resultado.MENSAGENS, ConstantesGlobais.TIPO_MENSAGEM_ERRO);

                        //Verificar se a mensagem de erro foi encontrada.Login sem sucesso
                        if (_resultadoMensagem != null)
                            return (new RespostaLerWorksItemsDto(true, _resultadoMensagem.MENSAGEM));
                    }

                    //Caso não seja retornada nenhuma mensagem.Assume-se que não funcionou.
                    return (new RespostaLerWorksItemsDto(true, "Ocorreu um erro na verificação da Leitura dos WorkItems!"));
                }
            }
            catch (Exception Ex)
            {
                LogUtil.RegistrarErro(this.GetLogVerificarLerWorkItems(Ex));
                return (new RespostaLerWorksItemsDto(true, $"Ocorreu o seguinte erro ao Verificar os WorkItems.Erro: {Ex.Message}"));
            }
            finally
            {
                LogUtil.RegistrarInformacao(this.GetLogVerificarLerWorkItems(requisicaoLerWorkItems, false));
            }
        }

        private RespostaLerWorksItemsDto PrepararRespostaLerWorkItems(RespostaLerWorksItemsDto resposta)
        {
            resposta.ListaTipoWorkItems = new List<TipoWorkItemDto>();

            foreach (var itemContrato in resposta.Contrato)
            {
                resposta.ListaTipoWorkItems.Add(this.CriarTipoWorkItem(itemContrato.Id, itemContrato.TextoWorkItem, itemContrato.Tarefa,
                    itemContrato.DescricaoTarefa, itemContrato.Numero, itemContrato.Valor, ConstantesGlobais.TIPO_WORK_ITEM_CONTRATO,
                    TipoWorkItem.Contrato));
            }

            foreach (var itemMedicao in resposta.Medicao)
            {
                var _itemMedicaoWI = this.CriarTipoWorkItem(itemMedicao.Id, itemMedicao.TextoWorkItem, itemMedicao.Tarefa,
                    itemMedicao.DescricaoTarefa, itemMedicao.Numero, itemMedicao.Total, ConstantesGlobais.TIPO_WORK_ITEM_MEDICAO,
                    TipoWorkItem.Medicao);

                _itemMedicaoWI.TextoWorkItem = $"Número: {itemMedicao.Numero} " + Environment.NewLine +
                                               $"Pedido: {itemMedicao.Pedido} " + Environment.NewLine +
                                               $"Total: {itemMedicao.Total} " + Environment.NewLine +
                                               $"Valor do Boletim: {itemMedicao.ValorBoletim}";


                resposta.ListaTipoWorkItems.Add(_itemMedicaoWI);
            }

            foreach (var itemPedido in resposta.Pedido)
            {
                var _itemPedidoWI = this.CriarTipoWorkItem(itemPedido.Id, itemPedido.TextoWorkItem, itemPedido.Tarefa,
                    itemPedido.DescricaoTarefa, itemPedido.Numero, itemPedido.Valor, ConstantesGlobais.TIPO_WORK_ITEM_PEDIDO, TipoWorkItem.Pedido);

                _itemPedidoWI.TextoWorkItem = $"Número: {itemPedido.Numero} " + Environment.NewLine +
                                              $"Valor: {itemPedido.Valor} " + Environment.NewLine +
                                              $"Tipo de Contratação Pedido: {itemPedido.TipoDeContrato} " + Environment.NewLine +
                                              $"Fornecedor: {itemPedido.Fornecedor} " + Environment.NewLine +
                                              $"Última Aprovação: {itemPedido.UltimaAprovacao}";
                
                resposta.ListaTipoWorkItems.Add(_itemPedidoWI);
            }

            foreach (var itemRequisicao in resposta.Requisicao)
            {
                var _itemRequisicaoWI = this.CriarTipoWorkItem(itemRequisicao.Id, itemRequisicao.TextoWorkItem, itemRequisicao.Tarefa,
                                                               itemRequisicao.DescricaoTarefa, itemRequisicao.Numero, itemRequisicao.Valor,
                                                               ConstantesGlobais.TIPO_WORK_ITEM_REQUISICAO, TipoWorkItem.Requisicao);

                _itemRequisicaoWI.TextoWorkItem = $"Número: {itemRequisicao.Numero} " + Environment.NewLine +
                                                  $"Valor: {itemRequisicao.Valor} " + Environment.NewLine +
                                                  $"Tipo de Contratação Pedido: {itemRequisicao.TipoContratacao} " + Environment.NewLine;

                resposta.ListaTipoWorkItems.Add(_itemRequisicaoWI);
            }

            return (resposta);
        }

        private TipoWorkItemDto CriarTipoWorkItem(string id, string textoWorkItem, string tarefa, string descricaoTarefa, string numero,
            decimal valor, string descricaoTipoWorkItem, TipoWorkItem tipoWorkItem)
        {
            return (new TipoWorkItemDto()
            {
                DescricaoTarefa = descricaoTarefa,
                DescricaoTipoWorkItem = descricaoTipoWorkItem,
                Id = id,
                Numero = numero,
                Tarefa = tarefa,
                TextoWorkItem = textoWorkItem,
                TipoWorkItem = tipoWorkItem,
                Valor = valor
            });
        }

        private MensagemProcessamentoDto CriarMensagemProcessamento(ServicoIntegracaoSAP.ZSAPP_MENSAGEM_PROCESAMENTO mensagemProcessamento)
        {
            var _resultado = new MensagemProcessamentoDto()
            {
                Id = mensagemProcessamento.ID,
                Mensagem = mensagemProcessamento.MENSAGEM,
                TipoMensagem = mensagemProcessamento.TIPO_MENSAGEM
            };

            return (_resultado);
        }

        private List<MensagemProcessamentoDto> CriarMensagemProcessamento(ServicoIntegracaoSAP.ZSAPP_MENSAGEM_PROCESAMENTO[] mensagemProcessamento)
        {
            var _resultado = new List<MensagemProcessamentoDto>();

            foreach (var _itemMensagem in mensagemProcessamento)
                _resultado.Add(this.CriarMensagemProcessamento(_itemMensagem));

            return (_resultado);
        }

        private RequisicaoCompraDto CriarRequisicaoCompra(ServicoIntegracaoSAP.ZES_APP_SAIDA_DADOS_REQCOMPRA dadosReqCompra)
        {
            var _resultado = new RequisicaoCompraDto()
            {
                DataCriacao = dadosReqCompra.DATA_CRIACAO,
                DescricaoTarefa = dadosReqCompra.DESCRICAO_TAREFA,
                Id = dadosReqCompra.ID,
                Numero = dadosReqCompra.NUMERO,
                Tarefa = dadosReqCompra.TAREFA,
                TextoWorkItem = dadosReqCompra.TEXTO_WORKITEM,
                TipoContratacao = dadosReqCompra.TIPO_DE_CONTRATACAO,
                Valor = dadosReqCompra.VALOR
            };

            return (_resultado);
        }

        private List<RequisicaoCompraDto> CriarRequisicaoCompra(ServicoIntegracaoSAP.ZES_APP_SAIDA_DADOS_REQCOMPRA[] dadosReqCompra)
        {
            var _resultado = new List<RequisicaoCompraDto>();

            foreach (var _itemReqCompra in dadosReqCompra)
                _resultado.Add(this.CriarRequisicaoCompra(_itemReqCompra));

            return (_resultado);
        }

        private List<DadosMedicaoDto> CriarDadosMediciao(ServicoIntegracaoSAP.ZES_APP_SAIDA_DADOS_MEDICAO[] dadosMedicao)
        {
            var _resultado = new List<DadosMedicaoDto>();

            foreach (var _itemMedicao in dadosMedicao)
                _resultado.Add(this.CriarDadosMediciao(_itemMedicao));

            return (_resultado);
        }

        private DadosMedicaoDto CriarDadosMediciao(ServicoIntegracaoSAP.ZES_APP_SAIDA_DADOS_MEDICAO dadosMedicao)
        {
            var _resultado = new DadosMedicaoDto()
            {
                DataCriacao = dadosMedicao.DATA_CRIACAO,
                DescricaoTarefa = dadosMedicao.DESCRICAO_TAREFA,
                Id = dadosMedicao.ID,
                Numero = dadosMedicao.NUMERO,
                Pedido = dadosMedicao.PEDIDO,
                Tarefa = dadosMedicao.TAREFA,
                TextoWorkItem = dadosMedicao.TEXTO_WORKITEM,
                Total = dadosMedicao.TOTAL,
                ValorBoletim = dadosMedicao.VALOR_BOLETIM
            };

            if (dadosMedicao.INFORMACOES_COMPLEMENTARES != null)
            {
                foreach (var _itemInfoComplementar in dadosMedicao.INFORMACOES_COMPLEMENTARES)
                    _resultado.InformacoesComplementares.Add(new InformacoesComplementaresDto(_itemInfoComplementar.TEXTO));
            }

            return (_resultado);
        }

        private List<DadosContratoDto> CriarDadosContrato(ServicoIntegracaoSAP.ZES_APP_SAIDA_DADOS_CONTRATO[] dadosContrato)
        {
            var _listaDadosContrato = new List<DadosContratoDto>();

            foreach (var _itemDadosContrato in dadosContrato)
                _listaDadosContrato.Add(this.CriarDadosContrato(_itemDadosContrato));

            return (_listaDadosContrato);
        }

        private DadosContratoDto CriarDadosContrato(ServicoIntegracaoSAP.ZES_APP_SAIDA_DADOS_CONTRATO dadosContrato)
        {
            var _resultado = new DadosContratoDto()
            {
                DataCriacao = dadosContrato.DATA_CRIACAO,
                DescricaoTarefa = dadosContrato.DESCRICAO_TAREFA,
                Fornecedor = dadosContrato.FORNECEDOR,
                Id = dadosContrato.ID,
                Numero = dadosContrato.NUMERO,
                Tarefa = dadosContrato.TAREFA,
                TextoWorkItem = dadosContrato.TEXTO_WORKITEM,
                TipoDeContrato = dadosContrato.TIPO_DE_CONTRATO,
                UltimaAprovacao = dadosContrato.ULTIMA_APROVACAO,
                Valor = dadosContrato.VALOR
            };

            if (dadosContrato.INFORMACOES_COMPLEMENTARES != null)
            {
                foreach (var _infoComp in dadosContrato.INFORMACOES_COMPLEMENTARES)
                    _resultado.InformacoesComplementares.Add(new InformacoesComplementaresDto(_infoComp.TEXTO));
            }

            return (_resultado);
        }

        /// <summary>
        /// Método responsável por realizar o login
        /// </summary>
        /// <param name="requisicaoLogin">Login a ser efetuado</param>
        /// <returns>Retorna uma resposta indicando se o login foi efetuado</returns>
        [HttpPost()]
        [Route("VerificarLogin")]
        [Produces(typeof(RespostaLoginDto))]
        [ProducesResponseType(typeof(RespostaLoginDto), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Consumes(APPLICATION_JSON)]
        public async Task<RespostaLoginDto> VerificarLogin([FromBody] RequisicaoLoginDto requisicaoLogin)
        {
            try
            {
                LogUtil.RegistrarInformacao(this.GetLogVerificarLogin(requisicaoLogin, true));

                if (!ModelState.IsValid)
                    return (new RespostaLoginDto(true, $"A requisição não é válida!"));

                //Dados fakes.Somente para teste. Remover depois
                /*return (new RespostaLoginDto(false)
                {
                    LoginGerado = new LoginGeradoDto()
                    {
                        DataCriacao = DateTime.Now,
                        UsuarioSAP = requisicaoLogin.UsuarioSAP
                    }
                });*/

                using (var _cliente = this.CriarClienteConexao())
                {
                    var _resultado = _cliente.Z_APROVACAO_WORFLOW_VIA_APP(this.CriarVerificarEvento(requisicaoLogin));

                    if (_resultado.MENSAGENS != null &&
                        _resultado.MENSAGENS.GetLength(0) > 0)
                    {
                        //Procura pela mensagem de sucesso
                        var _resultadoMensagem = this.BuscarTipoMensagem(_resultado.MENSAGENS, ConstantesGlobais.TIPO_MENSAGEM_SUCESSO);

                        //Verificar se o login foi efetuado com sucesso
                        if (_resultadoMensagem != null)
                            return (new RespostaLoginDto(false, String.Empty)
                            {
                                LoginGerado = new LoginGeradoDto(requisicaoLogin.UsuarioSAP, DateTime.Now)
                            });

                        //Procura pela mensagem de erro
                        _resultadoMensagem = this.BuscarTipoMensagem(_resultado.MENSAGENS, ConstantesGlobais.TIPO_MENSAGEM_ERRO);

                        //Verificar se a mensagem de erro foi encontrada.Login sem sucesso
                        if (_resultadoMensagem != null)
                            return (new RespostaLoginDto(true, _resultadoMensagem.MENSAGEM));
                    }

                    //Caso não seja retornada nenhuma mensagem.Assume-se que não funcionou.
                    return (new RespostaLoginDto(true, "Login ou senha incorretos!"));
                }
            }
            catch (Exception Ex)
            {
                LogUtil.RegistrarErro(this.GetLogVerificarLogin(Ex));
                return (new RespostaLoginDto(true, $"Ocorreu o seguinte erro ao tentar verificar o login.Erro: {Ex.Message}"));
            }
            finally
            {
                LogUtil.RegistrarInformacao(this.GetLogVerificarLogin(requisicaoLogin, false));
            }
        }

        private ServicoIntegracaoSAP.ZSAPP_MENSAGEM_PROCESAMENTO BuscarTipoMensagem(ServicoIntegracaoSAP.ZSAPP_MENSAGEM_PROCESAMENTO[] listaMensagens,
            string tipoMensagemBuscar)
        {
            return (listaMensagens.Where(i => i.TIPO_MENSAGEM == tipoMensagemBuscar).FirstOrDefault());
        }

        private ServicoIntegracaoSAP.Z_APROVACAO_WORFLOW_VIA_APP CriarVerificarEvento(RequisicaoReprovarWorkItemDto requisicaoLerWorkItems)
        {
            var _evento = this.CriarVerificarEvento(ConstantesGlobais.EVENTO_REPROVAR_WORK_ITEM, requisicaoLerWorkItems.UsuarioSAP, requisicaoLerWorkItems.SenhaSAP);
            var _listaEvento = new List<ServicoIntegracaoSAP.ZES_APROVAR_REJEITAR_WORKITEM>();

            foreach (var _item in requisicaoLerWorkItems.Item)
            {
                var _itemReprovar = this.CriarItemAprovarReprovar(ConstantesGlobais.EVENTO_ACAO_REPROVACAO, _item.Id);
                var _listaJustificativa = new List<ServicoIntegracaoSAP.TLINE>();

                _listaJustificativa.Add(new ServicoIntegracaoSAP.TLINE()
                {
                    TDFORMAT = "*",
                    TDLINE = _item.Justificativa
                });

                _itemReprovar.JUSTIFICATIVA = _listaJustificativa.ToArray();
                _listaEvento.Add(_itemReprovar);
            }

            _evento.APROVACAO = _listaEvento.ToArray();

            return (_evento);
        }

        private ServicoIntegracaoSAP.ZES_APROVAR_REJEITAR_WORKITEM CriarItemAprovarReprovar(string acao, string id)
        {
            var _justifica = new List<ServicoIntegracaoSAP.TLINE>();

            return (new ServicoIntegracaoSAP.ZES_APROVAR_REJEITAR_WORKITEM()
            {
                ACAO = acao,
                ID = id,
                JUSTIFICATIVA = _justifica.ToArray()
            });
        }

        private ServicoIntegracaoSAP.Z_APROVACAO_WORFLOW_VIA_APP CriarVerificarEvento(RequisicaoAprovarWorkItemDto requisicaoLerWorkItems)
        {
            var _evento = this.CriarVerificarEvento(ConstantesGlobais.EVENTO_APROVAR_WORK_ITEM, requisicaoLerWorkItems.UsuarioSAP, requisicaoLerWorkItems.SenhaSAP);

            var _listaEvento = new List<ServicoIntegracaoSAP.ZES_APROVAR_REJEITAR_WORKITEM>();

            foreach (var _item in requisicaoLerWorkItems.Item)
                _listaEvento.Add(this.CriarItemAprovarReprovar(ConstantesGlobais.EVENTO_ACAO_APROVACAO, _item.Id));

            _evento.APROVACAO = _listaEvento.ToArray();

            return (_evento);
        }

        private ServicoIntegracaoSAP.Z_APROVACAO_WORFLOW_VIA_APP CriarVerificarEvento(RequisicaoLerWorksItemsDto requisicaoLerWorkItems)
        {
            return (this.CriarVerificarEvento(ConstantesGlobais.EVENTO_LER_WORK_ITEMS, requisicaoLerWorkItems.UsuarioSAP, requisicaoLerWorkItems.SenhaSAP));
        }

        private ServicoIntegracaoSAP.Z_APROVACAO_WORFLOW_VIA_APP CriarVerificarEvento(RequisicaoLoginDto requisicaoLogin)
        {
            return (this.CriarVerificarEvento(ConstantesGlobais.EVENTO_VERIFICAR_LOGIN, requisicaoLogin.UsuarioSAP, requisicaoLogin.SenhaSAP));
        }

        private ServicoIntegracaoSAP.Z_APROVACAO_WORFLOW_VIA_APP CriarVerificarEvento(string evento, string usuarioSAP, string senhaSAP)
        {
            var _aprovacaoVazia = new List<ServicoIntegracaoSAP.ZES_APROVAR_REJEITAR_WORKITEM>();

            return (new ServicoIntegracaoSAP.Z_APROVACAO_WORFLOW_VIA_APP()
            {
                SENHA_SAP = senhaSAP,
                USUARIO_SAP = usuarioSAP,
                EVENTO = evento,
                APROVACAO = _aprovacaoVazia.ToArray()
            });
        }

        private ServicoIntegracaoSAP.z_aprovacao_worflow_via_app CriarClienteConexao()
        {
            var _cliente = new ServicoIntegracaoSAP.z_aprovacao_worflow_via_app();

            _cliente.Url = ConfigurationManager.AppSettings["UrlAPIIntegracao"];
            //_cliente.Url = "http://teste.avg.com.br:8088/sap/bc/srt/rfc/sap/z_aprovacao_worflow_via_app/500/z_aprovacao_worflow_via_app/zaprovacaowfviaapp";

            var _credenciais = new NetworkCredential(ConfigurationManager.AppSettings["UsuarioConexao"], ConfigurationManager.AppSettings["SenhaConexao"]);

            Uri uri = new Uri("http://teste.avg.com.br:8088/sap/bc/srt/rfc/sap/z_aprovacao_worflow_via_app/500/z_aprovacao_worflow_via_app/zaprovacaowfviaapp");
            ICredentials credentials = _credenciais.GetCredential(uri, "Basic");

            _cliente.PreAuthenticate = true;
            _cliente.Credentials = credentials;

            return (_cliente);
        }
    }
}