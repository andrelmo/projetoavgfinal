import { ObjetoLoginDto } from "./ObjetoLoginDto";

export class RequisicaoLoginDto extends ObjetoLoginDto {
    constructor() {
        super();
    }
}
