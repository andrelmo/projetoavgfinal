"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ObjetoLoginDto = void 0;
var ObjetoLoginDto = /** @class */ (function () {
    function ObjetoLoginDto() {
    }
    return ObjetoLoginDto;
}());
exports.ObjetoLoginDto = ObjetoLoginDto;
//# sourceMappingURL=ObjetoLoginDto.js.map