import { LoginGeradoDto } from "./LoginGeradoDto";
import { ObjetoRespostaBaseDto } from "./ObjetoRespostaBaseDto";

export class RespostaLoginDto extends ObjetoRespostaBaseDto {
    public LoginGerado!: LoginGeradoDto;

    constructor() {
        super();
        this.LoginGerado = new LoginGeradoDto();
    }
}
