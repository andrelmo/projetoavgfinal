export abstract class ObjetoRespostaBaseDto {
    public isErro!: boolean;
    public mensagemErro!: string;
}
