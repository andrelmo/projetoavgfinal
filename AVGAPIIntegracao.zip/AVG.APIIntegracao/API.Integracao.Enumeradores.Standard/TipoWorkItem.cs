﻿namespace API.Integracao.Enumeradores.Standard
{
    public enum TipoWorkItem
    {
        Contrato = 1,
        Medicao = 2,
        Pedido = 3,
        Requisicao = 4
    }
}