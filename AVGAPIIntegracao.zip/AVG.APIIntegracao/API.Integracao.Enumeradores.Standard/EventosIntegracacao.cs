﻿namespace API.Integracao.Enumeradores.Standard
{
    public enum EventosIntegracacao
    {
        /// <summary>
        /// Evento para verificar login
        /// </summary>
        VerificarLogin = 1,

        /// <summary>
        /// Evento para ler work items
        /// </summary>
        LerWorkItems = 2,

        /// <summary>
        /// Evento para Aprovar WorkItem
        /// </summary>
        AprovarWorkItem = 3,

        /// <summary>
        /// Evento para Reprovar WorkItem
        /// </summary>
        ReprovarWorkItem = 4
    }
}