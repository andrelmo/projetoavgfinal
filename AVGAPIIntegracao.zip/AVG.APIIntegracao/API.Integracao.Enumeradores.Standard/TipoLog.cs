﻿namespace API.Integracao.Enumeradores.Standard
{
    public enum TipoLog
    {
        Informacao = 1,
        Alerta = 2,
        Erro = 3
    }
}