﻿using API.Integracao.Constantes.Standard;
using API.Integracao.Enumeradores.Standard;

namespace API.Integracao.Utils.Standard
{
    public static class EventoUtils
    {
        public static string GetDescricaoEvento(EventosIntegracacao evento)
        {
            if (evento == EventosIntegracacao.VerificarLogin)
                return (ConstantesGlobais.EVENTO_VERIFICAR_LOGIN);
            else if (evento == EventosIntegracacao.AprovarWorkItem)
                return (ConstantesGlobais.EVENTO_APROVAR_WORK_ITEM);
            else if (evento == EventosIntegracacao.ReprovarWorkItem)
                return (ConstantesGlobais.EVENTO_REPROVAR_WORK_ITEM);
            else if (evento == EventosIntegracacao.LerWorkItems)
                return (ConstantesGlobais.EVENTO_LER_WORK_ITEMS);

            return (string.Empty);
        }
    }
}