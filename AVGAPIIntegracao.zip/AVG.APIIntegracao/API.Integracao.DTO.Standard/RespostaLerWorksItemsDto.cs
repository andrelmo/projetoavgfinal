﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace API.Integracao.DTO.Standard
{
    public class RespostaLerWorksItemsDto : ObjetoRespostaBaseDto
    {
        public List<DadosContratoDto> Contrato { get; set; }
        public List<DadosMedicaoDto> Medicao { get; set; }

        [JsonProperty]
        public List<MensagemProcessamentoDto> Mensagens { get; set; }
        public List<DadosContratoDto> Pedido { get; set; }
        public List<RequisicaoCompraDto> Requisicao { get; set; }

        [JsonProperty]
        public List<TipoWorkItemDto> ListaTipoWorkItems { get; set; }

        public RespostaLerWorksItemsDto() : this(false)
        {
            this.Contrato = new List<DadosContratoDto>();
            this.Medicao = new List<DadosMedicaoDto>();
            this.Mensagens = new List<MensagemProcessamentoDto>();
            this.Pedido = new List<DadosContratoDto>();
            this.Requisicao = new List<RequisicaoCompraDto>();
            this.ListaTipoWorkItems = new List<TipoWorkItemDto>();
        }

        public RespostaLerWorksItemsDto(bool isErro) : this(isErro, string.Empty)
        {

        }

        public RespostaLerWorksItemsDto(bool isErro, string mensagemErro) : base(isErro, mensagemErro)
        {

        }
    }
}