﻿using Newtonsoft.Json;

namespace API.Integracao.DTO.Standard
{
    public class RespostaAprovarWorkItemDto : ObjetoRespostaBaseDto
    {
        [JsonProperty]
        public string AprovadoPor { get; set; }

        public RespostaAprovarWorkItemDto() : this(false)
        {

        }

        public RespostaAprovarWorkItemDto(bool isErro) : this(isErro, string.Empty)
        {

        }

        public RespostaAprovarWorkItemDto(bool isErro, string mensagemErro) : base(isErro, mensagemErro)
        {

        }
    }
}