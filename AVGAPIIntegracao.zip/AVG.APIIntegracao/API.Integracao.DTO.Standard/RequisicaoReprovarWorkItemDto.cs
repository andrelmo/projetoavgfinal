﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace API.Integracao.DTO.Standard
{
    public class RequisicaoReprovarWorkItemDto : ObjetoLoginDto
    {
        [JsonProperty]
        public List<ItemAprovaReprovaWorkitemDto> Item { get; set; }

        [JsonProperty]
        public string ReprovadoPor { get; set; }

        public RequisicaoReprovarWorkItemDto()
        {

        }

        public RequisicaoReprovarWorkItemDto(List<ItemAprovaReprovaWorkitemDto> item, string reprovadoPor)
        {
            this.Item = item;
            this.ReprovadoPor = reprovadoPor;
        }
    }
}