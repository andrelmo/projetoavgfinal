﻿using Newtonsoft.Json;

namespace API.Integracao.DTO.Standard
{
    public class ItemAprovaReprovaWorkitemDto
    {
        [JsonProperty]
        public string Id { get; set; }

        [JsonProperty]
        public string Acao { get; set; }

        [JsonProperty]
        public string Justificativa { get; set; }

        public ItemAprovaReprovaWorkitemDto()
        {

        }

        public ItemAprovaReprovaWorkitemDto(int id, string acao)
        {

        }
    }
}