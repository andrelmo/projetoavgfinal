﻿using API.Integracao.Enumeradores.Standard;
using Newtonsoft.Json;

namespace API.Integracao.DTO.Standard
{
    public class TipoWorkItemDto
    {
        [JsonProperty]
        public string Id { get; set; }

        [JsonProperty]
        public string TextoWorkItem { get; set; }

        [JsonProperty]
        public string Tarefa { get; set; }

        [JsonProperty]
        public string DescricaoTarefa { get; set; }

        [JsonProperty]
        public string Numero { get; set; }

        [JsonProperty]
        public decimal Valor { get; set; }

        [JsonProperty]
        public string DescricaoTipoWorkItem { get; set; }

        [JsonProperty]
        public TipoWorkItem TipoWorkItem { get; set; }
    }
}