﻿using Newtonsoft.Json;

namespace API.Integracao.DTO.Standard
{
    public abstract class ObjetoLoginDto
    {
        [JsonProperty]
        public string UsuarioSAP { get; set; }

        [JsonProperty]
        public string SenhaSAP { get; set; }

        public ObjetoLoginDto() : this(string.Empty, string.Empty)
        {

        }

        public ObjetoLoginDto(string usuarioSAP, string senhaSAP)
        {
            this.UsuarioSAP = usuarioSAP;
            this.SenhaSAP = senhaSAP;
        }
    }
}