﻿namespace API.Integracao.DTO.Standard
{
    public class RequisicaoLoginDto : ObjetoLoginDto
    {

        public RequisicaoLoginDto() : this(string.Empty, string.Empty)
        {

        }

        public RequisicaoLoginDto(string usuarioSAP, string senhaSAP) : base(usuarioSAP, senhaSAP)
        {

        }
    }
}