﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace API.Integracao.DTO.Standard
{
    public class RespostaAprovacaoWorkFlowDto
    {
        [JsonProperty]
        public List<DadosContratoDto> Contrato { get; set; }

        [JsonProperty]
        public List<DadosMedicaoDto> Medicao { get; set; }

        [JsonProperty]
        public List<MensagemProcessamentoDto> Mensagens { get; set; }

        [JsonProperty]
        public List<DadosContratoDto> Pedido { get; set; }

        [JsonProperty]
        public List<RequisicaoCompraDto> Requisicao { get; set; }

        public RespostaAprovacaoWorkFlowDto()
        {
            this.Contrato = new List<DadosContratoDto>();
            this.Medicao = new List<DadosMedicaoDto>();
            this.Mensagens = new List<MensagemProcessamentoDto>();
            this.Pedido = new List<DadosContratoDto>();
            this.Requisicao = new List<RequisicaoCompraDto>();
        }
    }
}