﻿namespace API.Integracao.DTO.Standard
{
    public class RequisicaoLerWorksItemsDto : ObjetoLoginDto
    {
        public RequisicaoLerWorksItemsDto() : this(string.Empty, string.Empty)
        {

        }

        public RequisicaoLerWorksItemsDto(string usuarioSAP, string senhaSAP) : base(usuarioSAP, senhaSAP)
        {

        }
    }
}