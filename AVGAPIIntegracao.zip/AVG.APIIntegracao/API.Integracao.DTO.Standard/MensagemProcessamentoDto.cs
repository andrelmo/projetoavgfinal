﻿using Newtonsoft.Json;

namespace API.Integracao.DTO.Standard
{
    public class MensagemProcessamentoDto
    {
        [JsonProperty]
        public string TipoMensagem { get; set; }

        [JsonProperty]
        public string Mensagem { get; set; }

        [JsonProperty]
        public string Id { get; set; }
    }
}