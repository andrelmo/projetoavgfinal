﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace API.Integracao.DTO.Standard
{
    public class DadosMedicaoDto
    {
        [JsonProperty]
        public string Id { get; set; }

        [JsonProperty]
        public string TextoWorkItem { get; set; }

        [JsonProperty]
        public string Tarefa { get; set; }

        [JsonProperty]
        public string DescricaoTarefa { get; set; }

        [JsonProperty]
        public string DataCriacao { get; set; }

        [JsonProperty]
        public string Numero { get; set; }

        [JsonProperty]
        public string Pedido { get; set; }

        [JsonProperty]
        public decimal Total { get; set; }

        [JsonProperty]
        public decimal ValorBoletim { get; set; }

        public List<InformacoesComplementaresDto> InformacoesComplementares { get; set; }

        public DadosMedicaoDto() : base()
        {
            this.InformacoesComplementares = new List<InformacoesComplementaresDto>();
        }
    }
}