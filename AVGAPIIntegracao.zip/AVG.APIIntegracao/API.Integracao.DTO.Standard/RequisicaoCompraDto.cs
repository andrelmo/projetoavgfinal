﻿using Newtonsoft.Json;

namespace API.Integracao.DTO.Standard
{
    public class RequisicaoCompraDto
    {
        [JsonProperty]
        public string Id { get; set; }

        [JsonProperty]
        public string TextoWorkItem { get; set; }

        [JsonProperty]
        public string Tarefa { get; set; }

        [JsonProperty]
        public string DescricaoTarefa { get; set; }

        [JsonProperty]
        public string DataCriacao { get; set; }

        [JsonProperty]
        public string Numero { get; set; }

        [JsonProperty]
        public string TipoContratacao { get; set; }

        [JsonProperty]
        public decimal Valor { get; set; }
    }
}