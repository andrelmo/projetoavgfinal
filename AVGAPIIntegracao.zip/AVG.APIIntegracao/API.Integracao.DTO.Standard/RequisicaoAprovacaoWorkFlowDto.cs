﻿using Newtonsoft.Json;

namespace API.Integracao.DTO.Standard
{
    public class RequisicaoAprovacaoWorkFlowDto
    {
        [JsonProperty]
        public string Evento { get; set; }

        [JsonProperty]
        public string SenhaSAP { get; set; }

        [JsonProperty]
        public string UsuarioSAP { get; set; }
    }
}