﻿using Newtonsoft.Json;

namespace API.Integracao.DTO.Standard
{
    public class RespostaReprovarWorkItemDto : ObjetoRespostaBaseDto
    {
        [JsonProperty]
        public string ReprovadoPor { get; set; }

        public RespostaReprovarWorkItemDto() : this(false)
        {

        }

        public RespostaReprovarWorkItemDto(bool isErro) : this(isErro, string.Empty)
        {

        }

        public RespostaReprovarWorkItemDto(bool isErro, string mensagemErro) : base(isErro, mensagemErro)
        {

        }
    }
}