﻿using Newtonsoft.Json;
using System;

namespace API.Integracao.DTO.Standard
{
    public class LoginGeradoDto
    {
        [JsonProperty]
        public string UsuarioSAP { get; set; }

        [JsonProperty]
        public DateTime DataCriacao { get; set; }

        public LoginGeradoDto() : this(string.Empty, DateTime.Now)
        {

        }

        public LoginGeradoDto(string usuarioSAP, DateTime dataCriacao)
        {
            this.UsuarioSAP = usuarioSAP;
            this.DataCriacao = dataCriacao;
        }
    }
}