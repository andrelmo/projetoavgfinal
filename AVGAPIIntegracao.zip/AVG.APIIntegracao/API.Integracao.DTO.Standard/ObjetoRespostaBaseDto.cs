﻿using Newtonsoft.Json;

namespace API.Integracao.DTO.Standard
{
    public abstract class ObjetoRespostaBaseDto
    {
        [JsonProperty]
        public bool IsErro { get; set; }

        [JsonProperty]
        public string MensagemErro { get; set; }

        public ObjetoRespostaBaseDto(bool isErro) : this(isErro, string.Empty)
        {

        }

        public ObjetoRespostaBaseDto(bool isErro, string mensagemErro)
        {
            this.IsErro = isErro;
            this.MensagemErro = mensagemErro;
        }
    }
}