﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace API.Integracao.DTO.Standard
{
    public class RequisicaoAprovarWorkItemDto : ObjetoLoginDto
    {
        [JsonProperty]
        public List<ItemAprovaReprovaWorkitemDto> Item { get; set; }

        [JsonProperty]
        public string AprovadoPor { get; set; }

        public RequisicaoAprovarWorkItemDto()
        {

        }

        public RequisicaoAprovarWorkItemDto(List<ItemAprovaReprovaWorkitemDto> item, string aprovadorPor)
        {
            this.Item = item;
            this.AprovadoPor = aprovadorPor;
        }
    }
}