﻿using Newtonsoft.Json;

namespace API.Integracao.DTO.Standard
{
    public class InformacoesComplementaresDto
    {
        [JsonProperty]
        public string Texto { get; set; }

        public InformacoesComplementaresDto(string texto)
        {
            this.Texto = texto;
        }
    }
}