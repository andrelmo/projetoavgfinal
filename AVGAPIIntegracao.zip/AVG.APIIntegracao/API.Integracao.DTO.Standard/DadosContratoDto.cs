﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace API.Integracao.DTO.Standard
{
    public class DadosContratoDto
    {
        [JsonProperty]
        public string Numero { get; set; }

        [JsonProperty]
        public decimal Valor { get; set; }

        [JsonProperty]
        public string TipoDeContrato { get; set; }

        [JsonProperty]
        public string Fornecedor { get; set; }

        [JsonProperty]
        public string UltimaAprovacao { get; set; }

        [JsonProperty]
        public string Id { get; set; }

        [JsonProperty]
        public string TextoWorkItem { get; set; }

        [JsonProperty]
        public string Tarefa { get; set; }

        [JsonProperty]
        public string DescricaoTarefa { get; set; }

        [JsonProperty]
        public string DataCriacao { get; set; }

        [JsonProperty]
        public List<InformacoesComplementaresDto> InformacoesComplementares { get; set; }

        public DadosContratoDto() : base()
        {
            this.InformacoesComplementares = new List<InformacoesComplementaresDto>();
        }
    }
}