﻿using Newtonsoft.Json;

namespace API.Integracao.DTO.Standard
{
    public class RespostaLoginDto : ObjetoRespostaBaseDto
    {
        [JsonProperty]
        public LoginGeradoDto LoginGerado { get; set; }

        public RespostaLoginDto() : this(false)
        {
            this.LoginGerado = new LoginGeradoDto();
        }

        public RespostaLoginDto(bool isErro) : this(isErro, string.Empty)
        {

        }

        public RespostaLoginDto(bool isErro, string mensagemErro) : base(isErro, mensagemErro)
        {

        }
    }
}