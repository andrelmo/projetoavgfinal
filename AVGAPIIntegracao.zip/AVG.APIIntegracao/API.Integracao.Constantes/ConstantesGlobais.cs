﻿namespace API.Integracao.Constantes
{
    public static class ConstantesGlobais
    {
        /// <summary>
        /// Constante que representa o evento de verificar logihn
        /// </summary>
        public const string EVENTO_VERIFICAR_LOGIN = @"VERIFICAR_LOGIN";

        /// <summary>
        /// Constante que representa o evento de ler workitems
        /// </summary>
        public const string EVENTO_LER_WORK_ITEMS = @"LER_WORKITENS";

        /// <summary>
        /// Constante que representa o evento de aprovar work item
        /// </summary>
        public const string EVENTO_APROVAR_WORK_ITEM = @"APROVAR_WORKITEM";

        /// <summary>
        /// Constante que representa o evento de reprovar work item
        /// </summary>
        public const string EVENTO_REPROVAR_WORK_ITEM = @"REPROVAR_WORKITEM";

        /// <summary>
        /// Constante que define que um tipo de mensagem retornado pelo WebService de Integração é do tipo Erro
        /// </summary>
        public const string TIPO_MENSAGEM_ERRO = @"E";

        /// <summary>
        /// Constante que define se um tipo de mensagem retornado pelo WebService de Integração é do tipo Sucesso
        /// </summary>
        public const string TIPO_MENSAGEM_SUCESSO = @"S";

        /// <summary>
        /// Constante para formatação de data
        /// </summary>
        public const string FORMATAR_DATA = @"dd/MM/yyyy";

        /// <summary>
        /// Constante para formatação de data/hora
        /// </summary>
        public const string FORMATAR_DATA_HORA = @"dd/MM/yyyy hh:mm:ss";

        /// <summary>
        /// Constante que define o tipo de work de item igual a Contrato
        /// </summary>
        public const string TIPO_WORK_ITEM_CONTRATO = @"Contrato";

        /// <summary>
        /// Constante que define o tipo de work item igual a Medição
        /// </summary>
        public const string TIPO_WORK_ITEM_MEDICAO = @"Medição";

        /// <summary>
        /// Constante que define o tipo de work item igual a Pedido
        /// </summary>
        public const string TIPO_WORK_ITEM_PEDIDO = @"Pedido";

        /// <summary>
        /// Constante que define o tipo de work item igual a requisição
        /// </summary>
        public const string TIPO_WORK_ITEM_REQUISICAO = @"Requisição";
    }
}